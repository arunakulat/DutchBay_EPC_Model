# dutchbay_v13/adapters.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

try:
    import numpy_financial as npf  # recommended
except Exception:  # pragma: no cover - safe fallback
    npf = None

from .finance.debt import build_debt_schedule  # new module (see below)


# ---- tiny helpers -----------------------------------------------------------

def _as_float(d: Dict[str, Any], k: str, default: Optional[float] = None) -> Optional[float]:
    v = d.get(k)
    return float(v) if v is not None else default

def _truthy_env(*names: str) -> bool:
    import os
    for n in names:
        v = os.environ.get(n)
        if v and str(v).lower() not in ("0", "false", "no", "off", ""):
            return True
    return False


# ---- main public adapter ----------------------------------------------------

def run_irr_demo(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Minimal yet debt-aware adapter used by the CLI and tests.

    Equity-only mode (default):
      - Uses capex/opex/tariff/availability/loss_factor/lifetime to compute constant CFADS.
      - IRR is project == equity (no debt cashflows), DSCR proxy is 1.0 if CFADS ≥ 0 else 0.0.

    Debt-aware (auto-enabled when *any* debt key present):
      - Reads optional keys (interface remains backward-compatible):
        * debt_ratio, tenor_years, construction_grace_years
        * interest_rate_nominal  OR (base_rate + margin_bps)
        * target_dscr, min_dscr, dsra_months
        * dscr_probability_basis ("P50"/"P90") or dscr_haircut_factor
        * use_revenue_guarantee (bool), guarantee_revenue_pct (fee), guarantee_max_months (reserved)
      - Splits capex at COD into equity and debt.
      - Builds amortization profile:
          • Sculpt to target_dscr when provided (respect tenor & minimum DSCR),
          • Else annuity.
      - DSCR series is computed on (CFADS_haircut / debt_service).
      - Equity flows = CFADS − debt_service − fees − DSRA top-ups + DSRA releases.
      - IRR is computed on t0 equity injections + yearly equity flows.

    Strict finance mode (hard-fail):
      - If VALIDATION_MODE=strict or DB13_STRICT_FINANCE=1:
          * Raise on dscr_min < min_dscr (when min_dscr provided)
          * Raise when balloon principal remains at end of tenor
    """
    # ---- project primitives
    capex_usd = (_as_float(params, "capex_usd")
                 or (1e6 * _as_float(params, "capex_musd", 0.0))) or 0.0
    opex_usd = (_as_float(params, "opex_usd_per_year")
                or (1e6 * _as_float(params, "opex_musd_per_year", 0.0))) or 0.0

    capacity_mw = _as_float(params, "capacity_mw", 1.0) or 1.0
    lifetime = int(_as_float(params, "lifetime_years", 20) or 20)
    avail = (_as_float(params, "availability_pct", 95.0) or 95.0) / 100.0
    loss = (_as_float(params, "loss_factor", 0.0) or 0.0)

    # Tariff: USD/kWh preferred; fallback to 'tariff' if already USD/kWh (legacy)
    tariff_usd_per_kwh = _as_float(params, "tariff_usd_per_kwh")
    if tariff_usd_per_kwh is None:
        tariff_usd_per_kwh = _as_float(params, "tariff", 0.1) or 0.1

    # Production (flat for this adapter): MWh/yr = capacity * 8760 * avail * (1-loss)
    mwh_year = capacity_mw * 8760.0 * avail * max(0.0, 1.0 - loss)
    kwh_year = mwh_year * 1000.0
    revenue = tariff_usd_per_kwh * kwh_year
    cfads = revenue - opex_usd  # simple CFADS proxy

    annual_cfads = [cfads] * lifetime  # shape [1..N]

    # ---- detect debt presence (non-breaking)
    debt_keys = {
        "debt_ratio", "tenor_years", "construction_grace_years", "interest_rate_nominal",
        "base_rate", "margin_bps", "target_dscr", "min_dscr", "dsra_months",
        "dscr_probability_basis", "dscr_haircut_factor", "use_revenue_guarantee",
        "guarantee_revenue_pct", "guarantee_max_months"
    }
    has_debt_terms = any(k in params for k in debt_keys)

    # ---- pure equity mode (default)
    if not has_debt_terms:
        equity_cf = annual_cfads[:]  # no debt service/fees
        t0 = -capex_usd
        equity_irr = _irr([t0] + equity_cf)
        return {
            "equity_irr": equity_irr,
            "project_irr": equity_irr,
            "npv_12": 0.0,  # reserved
            "dscr_min": 1.0 if cfads >= 0 else 0.0,
            "annual": [{"year": y, "equity_cf": cfads, "dscr": 1.0 if cfads >= 0 else 0.0}
                       for y in range(1, lifetime + 1)],
        }

    # ---- debt parameters (optional defaults consistent with DFI norms)
    debt_ratio = _as_float(params, "debt_ratio", 0.70) or 0.70
    tenor_years = int(_as_float(params, "tenor_years", 15) or 15)
    grace = int(_as_float(params, "construction_grace_years", 0) or 0)

    if params.get("interest_rate_nominal") is not None:
        rate = _as_float(params, "interest_rate_nominal", 0.08) or 0.08
    else:
        base = _as_float(params, "base_rate", 0.045) or 0.045
        margin = (_as_float(params, "margin_bps", 350.0) or 350.0) / 1_00_00  # bps→decimal
        rate = base + margin

    target_dscr = _as_float(params, "target_dscr")
    min_dscr = _as_float(params, "min_dscr")
    dsra_months = int(_as_float(params, "dsra_months", 0) or 0)

    # probability haircut (P50/P90)
    haircut = _haircut_factor(params)

    use_guarantee = bool(params.get("use_revenue_guarantee", False))
    guarantee_fee = _as_float(params, "guarantee_revenue_pct", 0.0075) or 0.0075
    # guarantee_max_months reserved for future arrears modelling

    # ----- debt build
    debt_draw = debt_ratio * capex_usd
    equity_draw = capex_usd - debt_draw

    sched = build_debt_schedule(
        cfads_series=[c * haircut for c in annual_cfads],
        debt_amount=debt_draw,
        rate=rate,
        tenor_years=tenor_years,
        grace_years=grace,
        target_dscr=target_dscr,
        min_dscr=min_dscr,
        dsra_months=0 if use_guarantee else dsra_months,
    )

    # fees/guarantee
    fee_series = [(revenue * guarantee_fee) if use_guarantee else 0.0 for _ in annual_cfads]

    # equity cashflows
    equity_flows = []
    dscr_min = float("inf")
    for y in range(lifetime):
        ds = sched.debt_service[y] if y < len(sched.debt_service) else 0.0
        dsra_topup = sched.dsra_topups[y] if y < len(sched.dsra_topups) else 0.0
        dsra_release = sched.dsra_releases[y] if y < len(sched.dsra_releases) else 0.0
        eq = annual_cfads[y] - ds - fee_series[y] - dsra_topup + dsra_release
        equity_flows.append(eq)
        if y < len(sched.dscr):
            dscr_min = min(dscr_min, sched.dscr[y])

    # IRRs
    equity_irr = _irr([-equity_draw] + equity_flows)
    proj_irr = _irr([-capex_usd] + annual_cfads)  # simple “project” reference

    # strict breaches raise
    if _truthy_env("DB13_STRICT_FINANCE", "VALIDATION_MODE") and \
       (sched.balloon_remaining > 1e-6 or (min_dscr is not None and dscr_min < min_dscr - 1e-9)):
        reason = []
        if sched.balloon_remaining > 1e-6:
            reason.append(f"balloon_remaining={sched.balloon_remaining:,.2f} > 0")
        if min_dscr is not None and dscr_min < min_dscr - 1e-9:
            reason.append(f"dscr_min={dscr_min:.2f} < min_dscr={min_dscr:.2f}")
        raise ValueError("Finance strict breach: " + "; ".join(reason))

    # annual report
    annual_rows = []
    for i in range(lifetime):
        annual_rows.append({
            "year": i + 1,
            "equity_cf": equity_flows[i],
            "dscr": sched.dscr[i] if i < len(sched.dscr) else 0.0,
            "debt_service": sched.debt_service[i] if i < len(sched.debt_service) else 0.0,
            "interest": sched.interest[i] if i < len(sched.interest) else 0.0,
            "principal": sched.principal[i] if i < len(sched.principal) else 0.0,
        })

    return {
        "equity_irr": equity_irr,
        "project_irr": proj_irr,
        "npv_12": 0.0,
        "dscr_min": dscr_min if dscr_min != float("inf") else (1.0 if cfads >= 0 else 0.0),
        "balloon_remaining": sched.balloon_remaining,
        "annual": annual_rows,
    }


def _irr(cashflows: List[float]) -> float:
    if npf is None:
        return 0.0
    try:
        return float(npf.irr(cashflows))
    except Exception:
        return 0.0


def _haircut_factor(params: Dict[str, Any]) -> float:
    # explicit factor wins
    f = _as_float(params, "dscr_haircut_factor")
    if f is not None:
        return max(0.0, min(1.0, f))
    # P-value basis
    basis = str(params.get("dscr_probability_basis", "P50")).upper()
    if basis == "P90":
        return 0.90
    return 1.00

    