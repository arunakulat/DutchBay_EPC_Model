# dutchbay_v13/finance/debt.py
from __future__ import annotations
from typing import List, Dict, Optional
import math


def _annuity_payment(principal: float, rate: float, n_periods: int) -> float:
    """
    Constant annual payment for rate per period; handles rate≈0.
    """
    if n_periods <= 0:
        return 0.0
    if abs(rate) < 1e-12:
        return principal / n_periods
    r = rate
    return principal * (r * (1 + r) ** n_periods) / ((1 + r) ** n_periods - 1)


def _simulate_schedule_with_profile(
    principal: float,
    rate: float,
    profile: List[float],
    grace_years: int,
) -> Dict[str, List[float] | float]:
    """
    Simulate with a given total-debt-service profile.
    During grace: DS = interest (principal holiday).
    After grace: DS from `profile`.
    """
    n = len(profile)
    opening: List[float] = []
    interest: List[float] = []
    principal_vec: List[float] = []
    debt_service: List[float] = []
    closing: List[float] = []

    bal = principal
    for y in range(1, n + 1):
        opening.append(bal)
        int_y = bal * rate
        if y <= grace_years:
            ds_y = int_y
            p_y = 0.0
        else:
            ds_y = max(0.0, profile[y - 1])
            p_y = max(0.0, ds_y - int_y)
        bal = max(0.0, bal - p_y)
        interest.append(int_y)
        principal_vec.append(p_y)
        debt_service.append(ds_y)
        closing.append(bal)

    balloon = closing[-1] if closing else 0.0
    return {
        "opening": opening,
        "interest": interest,
        "principal": principal_vec,
        "debt_service": debt_service,
        "closing": closing,
        "balloon_remaining": balloon,
    }


def sculpt_debt_schedule(
    cfads_for_debt: List[float],
    principal: float,
    rate: float,
    tenor_years: int,
    grace_years: int = 0,
    target_dscr: Optional[float] = None,
    min_dscr: Optional[float] = None,
    method: str = "auto",
) -> Dict[str, List[float] | float]:
    """
    Build an annual debt schedule.

    Modes
    -----
    - DSCR sculpt (if target_dscr provided or method='sculpt'):
        base_y = CFADS_y / target_dscr (post-grace; 0 during grace)
        envelope cap from min_dscr (if provided): DS_y <= CFADS_y / min_dscr
        Find scalar k so terminal balance ~ 0 subject to caps (bisection).
        If impossible under caps → return a schedule with balloon_remaining > 0.

    - Annuity (if no target_dscr or method='annuity'):
        Grace: interest only
        Post-grace: constant payment (annuity) for remaining years.
    """
    n = max(0, int(tenor_years))
    g = max(0, int(grace_years))
    n = max(n, g)
    if n == 0:
        return {"opening": [], "interest": [], "principal": [],
                "debt_service": [], "closing": [], "dscr": [], "balloon_remaining": 0.0}

    # Align CFADS to tenor length
    if len(cfads_for_debt) < n:
        cfads_for_debt = cfads_for_debt + [cfads_for_debt[-1]] * (n - len(cfads_for_debt))
    cfads_for_debt = cfads_for_debt[:n]

    do_sculpt = (method.lower() == "sculpt") or (target_dscr is not None and method.lower() == "auto")

    if not do_sculpt:
        # ---------- Annuity ----------
        pay_years = max(0, n - g)
        ann = _annuity_payment(principal, rate, pay_years) if pay_years > 0 else 0.0
        profile = [0.0 if y <= g else ann for y in range(1, n + 1)]
        sched = _simulate_schedule_with_profile(principal, rate, profile, grace_years=g)

    else:
        # ---------- DSCR sculpt ----------
        t_dscr = float(target_dscr) if target_dscr and target_dscr > 0 else 1.30
        m_cap = float(min_dscr) if (min_dscr and min_dscr > 0 and min_dscr <= t_dscr) else None

        base: List[float] = []
        envelope: List[float] = []
        INF = 1e30
        for y in range(1, n + 1):
            cf = cfads_for_debt[y - 1]
            if y <= g:
                base.append(0.0)
                envelope.append(INF if m_cap is None else (cf / m_cap))
            else:
                base.append(max(0.0, cf / t_dscr))
                envelope.append(INF if m_cap is None else (cf / m_cap))

        def end_balance(k: float) -> float:
            prof = [min(k * base[i], envelope[i]) for i in range(n)]
            return float(_simulate_schedule_with_profile(principal, rate, prof, grace_years=g)["balloon_remaining"])

        # Grow upper bound until over-amortized or saturated by caps
        klo, khi = 0.0, 1.0
        bal_hi = end_balance(khi)
        attempts = 0
        while bal_hi > 1e-6 and attempts < 40:
            khi *= 2.0
            prev = bal_hi
            bal_hi = end_balance(khi)
            attempts += 1
            if abs(bal_hi - prev) < 1e-6:  # saturated by envelope
                break

        if bal_hi > 1e-6:
            # Cannot fully amortize under caps → accept balloon
            k_use = khi
            prof = [min(k_use * base[i], envelope[i]) for i in range(n)]
            sched = _simulate_schedule_with_profile(principal, rate, prof, grace_years=g)
        else:
            # Bisection for k
            for _ in range(60):
                kmid = 0.5 * (klo + khi)
                bal_mid = end_balance(kmid)
                if abs(bal_mid) <= 1e-6:
                    klo = khi = kmid
                    break
                if bal_mid > 0:
                    klo = kmid
                else:
                    khi = kmid
            k_use = 0.5 * (klo + khi)
            prof = [min(k_use * base[i], envelope[i]) for i in range(n)]
            sched = _simulate_schedule_with_profile(principal, rate, prof, grace_years=g)

    # DSCR series for debt years (use cfads_for_debt passed in; DSCR is covenant basis)
    dscr: List[float] = []
    for y in range(1, n + 1):
        ds = sched["debt_service"][y - 1]
        cf = cfads_for_debt[y - 1]
        if ds <= 1e-12:
            dscr.append(float("inf") if cf > 0 else 0.0)
        else:
            dscr.append(cf / ds)

    sched["dscr"] = dscr
    return sched

    