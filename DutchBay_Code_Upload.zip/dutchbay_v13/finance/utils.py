from __future__ import annotations


def pow1p(x: float, n: int) -> float:
    return (1.0 + x) ** n
