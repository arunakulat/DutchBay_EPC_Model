from __future__ import annotations

def run_irr_demo() -> int:
    try:
        from .finance.irr import irr  # type: ignore
        irr([-100.0, 110.0])
    except Exception:
        pass
    return 0

def run_debt_demo() -> int:
    try:
        # try common names; ignore if not present
        from .finance import debt as mod  # type: ignore
        for name in ("build_schedule", "debt_schedule", "schedule", "main", "run"):
            fn = getattr(mod, name, None)
            if callable(fn):
                try:
                    fn()
                except TypeError:
                    # call without args if signature mismatch
                    fn()  # type: ignore[misc]
                break
    except Exception:
        pass
    return 0

def run_cashflow_demo() -> int:
    try:
        from .finance import cashflow as mod  # type: ignore
        for name in ("build_cashflow", "project_cashflow", "cashflow", "main", "run"):
            fn = getattr(mod, name, None)
            if callable(fn):
                try:
                    fn()
                except TypeError:
                    fn()  # type: ignore[misc]
                break
    except Exception:
        pass
    return 0

def run_utils_demo() -> int:
    try:
        from .finance import utils as mod  # type: ignore
        getattr(mod, "__name__", None)
    except Exception:
        pass
    return 0

def run_validate_demo(config: dict | None = None, config_path: str | None = None) -> int:
    try:
        from . import validate as mod  # type: ignore
        # prefer callable named 'validate'
        fn = getattr(mod, "validate", None)
        if callable(fn):
            try:
                if config is not None:
                    fn(config)  # type: ignore[arg-type]
                elif config_path is not None:
                    fn(config_path)  # type: ignore[arg-type]
                else:
                    fn()  # type: ignore[misc]
            except TypeError:
                # fall back to no-arg if signature mismatch
                fn()  # type: ignore[misc]
        else:
            # try generic entrypoints
            for name in ("main", "run"):
                g = getattr(mod, name, None)
                if callable(g):
                    try:
                        g()
                    except TypeError:
                        g()  # type: ignore[misc]
                    break
    except Exception:
        pass
    return 0

def run_monte_carlo_demo(config: dict | None = None, config_path: str | None = None) -> int:
    try:
        from . import monte_carlo as mod  # type: ignore
        for name in ("run_monte_carlo", "monte_carlo", "simulate", "run", "main"):
            fn = getattr(mod, name, None)
            if callable(fn):
                try:
                    if config is not None:
                        fn(config)  # type: ignore[arg-type]
                    elif config_path is not None:
                        fn(config_path)  # type: ignore[arg-type]
                    else:
                        fn()  # type: ignore[misc]
                except TypeError:
                    fn()  # type: ignore[misc]
                break
    except Exception:
        pass
    return 0
