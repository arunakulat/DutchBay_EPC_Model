from __future__ import annotations

import argparse
import importlib
import inspect
import sys
from pathlib import Path
from typing import Any, Dict, List

from .scenario_runner import run_scenario_matrix

HANDLERS: Dict[str, Dict[str, str]] = {
  "baseline": {
    "mode": "baseline",
    "module": "dutchbay_v13.cli",
    "func": "main",
    "file": "dutchbay_v13/cli.py"
  },
  "sensitivity": {
    "mode": "sensitivity",
    "module": "dutchbay_v13.cli",
    "func": "main",
    "file": "dutchbay_v13/cli.py"
  },
  "optimize": {
    "mode": "optimize",
    "module": "dutchbay_v13.cli",
    "func": "main",
    "file": "dutchbay_v13/cli.py"
  },
  "report": {
    "mode": "report",
    "module": "dutchbay_v13.cli",
    "func": "main",
    "file": "dutchbay_v13/cli.py"
  },
  "irr": {
    "mode": "irr",
    "module": "dutchbay_v13.adapters",
    "func": "run_irr_demo",
    "file": "dutchbay_v13/adapters.py"
  },
  "debt": {
    "mode": "debt",
    "module": "dutchbay_v13.adapters",
    "func": "run_debt_demo",
    "file": "dutchbay_v13/adapters.py"
  },
  "cashflow": {
    "mode": "cashflow",
    "module": "dutchbay_v13.adapters",
    "func": "run_cashflow_demo",
    "file": "dutchbay_v13/adapters.py"
  },
  "utils": {
    "mode": "utils",
    "module": "dutchbay_v13.adapters",
    "func": "run_utils_demo",
    "file": "dutchbay_v13/adapters.py"
  },
  "validate": {
    "mode": "validate",
    "module": "dutchbay_v13.adapters",
    "func": "run_validate_demo",
    "file": "dutchbay_v13/adapters.py"
  },
  "montecarlo": {
    "mode": "montecarlo",
    "module": "dutchbay_v13.adapters",
    "func": "run_monte_carlo_demo",
    "file": "dutchbay_v13/adapters.py"
  },
  "epc": {
    "mode": "epc",
    "module": "dutchbay_v13.epc",
    "func": "run_epc",
    "file": "dutchbay_v13/epc.py"
  }
}
MODES: List[str] = ["baseline", "sensitivity", "optimize", "scenarios", "report", "api", "irr", "debt", "cashflow", "utils", "validate", "montecarlo", "epc"]

def parse_args(argv: List[str] | None = None) -> tuple[argparse.Namespace, argparse.ArgumentParser]:
    p = argparse.ArgumentParser(prog="dutchbay", description="Dutch Bay financial model CLI")
    p.add_argument("--mode", choices=MODES, help="Run mode")
    p.add_argument("--config", help="YAML config path for baseline/sensitivity/optimize/report/validate/montecarlo")
    p.add_argument("--outputs-dir", default="outputs", help="Output directory root")
    p.add_argument("--format", choices=["jsonl", "csv", "both"], default="csv", help="Scenario output format")
    p.add_argument("--save-annual", action="store_true", help="Save annual CSVs (if supported)")
    p.add_argument("--scenarios-dir", default="inputs/scenarios", help="Directory or file for scenarios")
    p.add_argument("--scenarios", nargs="+", help="One or more scenario paths (files or directories)")
    return p.parse_args(argv), p

def _call_handler(mode: str, a: argparse.Namespace) -> int:
    h = HANDLERS.get(mode)
    if not h:
        print(f"No handler mapped for mode '{mode}'", file=sys.stderr)
        return 2
    mod = importlib.import_module(h["module"])
    fn = getattr(mod, h["func"])

    # Dispatch log for CI/debug
    print(f"Dispatching mode {mode} -> {h['module']}::{h['func']}")

    # Load YAML config if provided
    cfg: Dict[str, Any] | None = None
    if getattr(a, "config", None):
        try:
            import yaml  # type: ignore
            cfg = yaml.safe_load(Path(a.config).read_text(encoding="utf-8")) or {}
        except Exception as e:
            print(f"Failed to load config {a.config}: {e}", file=sys.stderr)
            return 1

    # Prepare kwargs by introspecting the function signature
    sig = inspect.signature(fn)
    kwargs: Dict[str, Any] = {}
    for name in sig.parameters.keys():
        if name in {"config", "cfg"} and cfg is not None:
            kwargs[name] = cfg
        elif name in {"config_path", "cfg_path", "yaml_path"} and getattr(a, "config", None):
            kwargs[name] = a.config
        elif name in {"out_dir", "outputs_dir"}:
            kwargs[name] = a.outputs_dir
        elif name == "save_annual":
            kwargs[name] = bool(getattr(a, "save_annual", False))
        elif name == "fmt":
            kwargs[name] = getattr(a, "format", "csv")

    try:
        res = fn(**kwargs)  # type: ignore[arg-type]
    except TypeError:
        # Signature mismatch: try no-arg call
        res = fn()  # type: ignore[misc]

    if isinstance(res, int):
        return res
    return 0

def main(argv: List[str] | None = None) -> int:
    a, parser = parse_args(argv)
    if a.mode is None:
        parser.print_help(sys.stderr)
        return 2
    try:
        if a.mode == "api":
            from .api import run as run_api  # type: ignore
            run_api()
            return 0
        if a.mode == "scenarios":
            paths = a.scenarios if a.scenarios else [a.scenarios_dir]
            out = str(Path(a.outputs_dir) / "scenarios")
            n, w = run_scenario_matrix(paths, out, fmt=a.format, save_annual=a.save_annual)
            print(f"Processed {n} scenario files; wrote {w} records -> {out}")
            return 0
        if a.mode in HANDLERS:
            return _call_handler(a.mode, a)
    except Exception as e:
        print(f"{a.mode} failed: {e}", file=sys.stderr)
        return 1
    parser.print_help(sys.stderr)
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
