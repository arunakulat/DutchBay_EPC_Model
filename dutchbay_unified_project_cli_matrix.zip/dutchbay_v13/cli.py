from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .scenario_runner import run_scenario_matrix

MODES = ["baseline", "sensitivity", "optimize", "scenarios", "report", "api"]

def parse_args(argv: list[str] | None = None) -> tuple[argparse.Namespace, argparse.ArgumentParser]:
    p = argparse.ArgumentParser(prog="dutchbay", description="Dutch Bay financial model CLI")
    p.add_argument("--mode", choices=MODES, help="Run mode")
    # scenarios
    p.add_argument("--scenarios-dir", default="inputs/scenarios", help="Directory or file for scenarios")
    p.add_argument("--outputs-dir", default="outputs/scenarios", help="Output directory")
    p.add_argument("--format", choices=["jsonl", "csv", "both"], default="csv", help="Output format")
    p.add_argument("--save-annual", action="store_true", help="Save annual CSVs (if supported)")
    return p.parse_args(argv), p

def _handle_scenarios(a: argparse.Namespace) -> int:
    inputs = a.scenarios_dir
    outputs = a.outputs_dir
    fmt = a.format
    n, w = run_scenario_matrix([inputs], outputs, fmt=fmt, save_annual=a.save_annual)
    print(f"Processed {n} scenario files; wrote {w} records -> {outputs}")
    return 0

def _handle_report(a: argparse.Namespace) -> int:
    # Placeholder; assume external report pipeline exists
    print("Report generation not implemented in CLI stub.")
    return 0

def _handle_baseline(a: argparse.Namespace) -> int:
    print("Baseline run not implemented in CLI stub.")
    return 0

def _handle_sensitivity(a: argparse.Namespace) -> int:
    print("Sensitivity run not implemented in CLI stub.")
    return 0

def _handle_optimize(a: argparse.Namespace) -> int:
    print("Optimizer not implemented in CLI stub.")
    return 0

def main(argv: list[str] | None = None) -> int:
    a, parser = parse_args(argv)
    if a.mode is None:
        parser.print_help(sys.stderr)
        return 2

    try:
        if a.mode == "api":
            from .api import run as run_api  # type: ignore
            run_api()
            return 0
        elif a.mode == "scenarios":
            return _handle_scenarios(a)
        elif a.mode == "report":
            return _handle_report(a)
        elif a.mode == "baseline":
            return _handle_baseline(a)
        elif a.mode == "sensitivity":
            return _handle_sensitivity(a)
        elif a.mode == "optimize":
            return _handle_optimize(a)
    except Exception as e:
        print(f"{a.mode} failed: {e}", file=sys.stderr)
        return 1

    parser.print_help(sys.stderr)
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
