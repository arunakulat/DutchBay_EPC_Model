## Summary
- [ ] Focused change (one area)
- [ ] Tests added/updated
- [ ] Docs updated (README / docs/schema.md / examples)
- [ ] Ran `pre-commit run --all-files` locally (black/flake8/isort/mypy)
- [ ] CI green (required check: **gate**)

### What changed?
- ...

### Screenshots / Charts (if applicable)
- ...

### Notes
- Any breaking changes or migrations?
